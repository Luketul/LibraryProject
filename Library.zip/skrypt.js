        document.getElementById('borrowForm').addEventListener('submit', function(event) 
        {
            event.preventDefault(); 
            
            let formData = new FormData(this);
            fetch(this.action, 
            {
                method: this.method,
                body: formData
            })
            .then(response => 
            {
                if (response.ok) 
                {
                    document.getElementById('successMessage').style.display = 'block';
                } 
                else 
                {
                    throw new Error('Network response was not ok');
                }
            })
            .catch(error => 
            {
                console.error('Error during form submission:', error);
            });
        });