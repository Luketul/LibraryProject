<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteka</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fff;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }
        .logo img {
            height: 200px;
            width: 180px;
        }
        .buttons {
            flex: 1;
        }
        .buttons a {
            padding: 30px 120px;
            margin: 30px;
            background-color: #00aeff;
            color: #fff;
            font-size: 16px;
            text-decoration: none;
        }
        .buttons a:hover {
            background-color: #0094cc;
        }
        .text {
            text-align: left;
            padding: 20px;
            margin: auto;
            max-width: 800px;
        }
        hr {
            width: 100%;
            margin: 10px;
        }
        .images {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }
        .images img {
            width: 100%;
            height: 500px;
            max-width: 100%;
            margin: 5px;
        }
    </style>
    <link rel="icon" href="linklogo.png" type="image/png">
</head>
<body>
    <div class="container">
        <div class="logo">
            <a href="main.php"><img src="linklogo.png" alt="Logo Biblioteki"></a>
        </div>
        <div class="buttons">
            <a href="booklist.php" class="button">Lista Książek</a>
            <a href="borrowbook.php" class="button">Wypożycz Książkę</a>
            <a href="contact.php" class="button">Kontakt</a>
        </div>
    </div>
    <hr>
    <div class="text">
        Nasza biblioteka to miejsce, które łączy tradycję z nowoczesnością,
         oferując bogaty zasób książek, czasopism oraz innych materiałów edukacyjnych i rozrywkowych. 
         Znajdziesz u nas szeroki wybór literatury pięknej, popularnonaukowej, podręczników oraz książek dla dzieci i młodzieży. 
         Dbamy o to, aby nasze zbiory były regularnie aktualizowane i uzupełniane o najnowsze pozycje.
    </div>
    <hr>
    <div class="images">
    <img src="biblioteka1.jpeg" height="300">
    </div>
    <hr>
    <div class="text">
    Oprócz możliwości wypożyczania książek, zapewniamy również dostęp do komfortowej strefy czytelniczej,
     gdzie możesz spokojnie przeglądać nasze zbiory, korzystać z dostępu do internetu oraz studiować. 
     Organizujemy różnorodne wydarzenia kulturalne, takie jak spotkania autorskie, warsztaty czytania dla dzieci, 
     jak również wystawy i prezentacje tematyczne.
    </div>
    <hr>
    <div class="images">
        <img src="biblioteka2.jpeg" height="300">
    </div>
    <hr>
    <img src="books.jpg" height=400 weight=300>
</body>
</html>
